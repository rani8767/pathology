# Pathology Management System - Comprehensive Test Cases Document

**Project Name:** Pathology Management System (Spring Boot REST API)  
**Version:** 1.0.0  
**Author:** Antigravity AI Engineering Team  
**Date:** September 2026  

---

## 📋 Table of Contents
1. [Overview](#1-overview)
2. [Test Strategy & Test Environment](#2-test-strategy--test-environment)
3. [Test Case Matrix Index](#3-test-case-matrix-index)
4. [Module 1: Patient Management Test Cases](#module-1-patient-management-test-cases)
5. [Module 2: Doctor / Referrer Management Test Cases](#module-2-doctor--referrer-management-test-cases)
6. [Module 3: Test Catalog & Category Test Cases](#module-3-test-catalog--category-test-cases)
7. [Module 4: Lab Order & Booking Test Cases](#module-4-lab-order--booking-test-cases)
8. [Module 5: Lab Results & Report Generation Test Cases](#module-5-lab-results--report-generation-test-cases)
9. [Module 6: Dashboard & Analytics Test Cases](#module-6-dashboard--analytics-test-cases)
10. [Module 7: System & Exception Handling Test Cases](#module-7-system--exception-handling-test-cases)
11. [Automated Test Execution Summary](#11-automated-test-execution-summary)

---

## 1. Overview

This document serves as the official master test specification for the **Pathology Management System**. It outlines all functional, non-functional, integration, boundary value analysis (BVA), and edge-case scenarios required to validate system reliability, accuracy in lab result reporting, billing integrity, and API compliance.

---

## 2. Test Strategy & Test Environment

### Test Frameworks & Tools
- **Unit Testing Framework:** JUnit 5 (Jupiter)
- **Mocking Framework:** Mockito 5
- **Integration Testing:** `@SpringBootTest` + `@AutoConfigureMockMvc`
- **Database:** In-Memory H2 Database
- **API Client Testing:** Postman v2.1 Collection & Swagger UI (`http://localhost:8080/swagger-ui.html`)

### Test Data Pre-requisites
- Pre-seeded Test Categories: Hematology, Biochemistry, Microbiology, Serology.
- Pre-seeded Test Master: Complete Blood Count (CBC), Fasting Blood Sugar (FBS), Lipid Profile, TSH.
- Pre-seeded Patients & Referring Doctors.

---

## 3. Test Case Matrix Index

| Module ID | Module Name | Total Cases | Pass Criteria |
| :--- | :--- | :--- | :--- |
| **PAT-TC** | Patient Management | 8 | 200 OK / 201 Created / 400 Bad Request |
| **DOC-TC** | Doctor Management | 6 | 200 OK / 201 Created / 404 Not Found |
| **TST-TC** | Test Catalog | 6 | 200 OK / 201 Created / 400 Duplicate |
| **ORD-TC** | Lab Order & Billing | 8 | 201 Created / Correct Calculation |
| **RPT-TC** | Lab Result & Reporting | 6 | Accurate Status (Normal/Abnormal/Critical) |
| **DSH-TC** | Dashboard Metrics | 3 | Accurate Aggregations |
| **SYS-TC** | Global Exceptions | 4 | RFC 7807 Error Response Formatting |

---

## Module 1: Patient Management Test Cases

### TC-PAT-001: Register New Patient (Positive)
- **Precondition:** System is running.
- **Input Payload:**
  ```json
  {
    "fullName": "Rahul Sharma",
    "age": 32,
    "gender": "MALE",
    "mobile": "9876543210",
    "email": "rahul.sharma@example.com",
    "address": "22 Connaught Place, New Delhi",
    "bloodGroup": "O+"
  }
  ```
- **Expected Result:** HTTP 201 Created. Response contains auto-generated `patientCode` (e.g. `PAT-XXXXXXXX`) and HTTP response `success: true`.

### TC-PAT-002: Register Patient Without Mandatory Fields (Negative)
- **Input Payload:** Missing `fullName`, missing `mobile`.
- **Expected Result:** HTTP 400 Bad Request. Response contains `validationErrors` map indicating `fullName: Full name is required` and `mobile: Mobile number is required`.

### TC-PAT-003: Register Patient With Invalid Age (Boundary / Negative)
- **Input Payload:** `age: -5` or `age: 200`.
- **Expected Result:** HTTP 400 Bad Request. Field validation error for `age`.

### TC-PAT-004: Register Patient With Invalid Mobile Format (Negative)
- **Input Payload:** `mobile: "123"` or `mobile: "abc1234567"`.
- **Expected Result:** HTTP 400 Bad Request. Validation error `Mobile number must be between 10 and 15 digits`.

### TC-PAT-005: Fetch All Patients (Positive)
- **Request:** `GET /api/v1/patients`
- **Expected Result:** HTTP 200 OK. Returns JSON array of registered patient objects.

### TC-PAT-006: Fetch Patient By Valid ID (Positive)
- **Request:** `GET /api/v1/patients/1`
- **Expected Result:** HTTP 200 OK. Patient object returned matching ID 1.

### TC-PAT-007: Fetch Patient By Non-existent ID (Negative)
- **Request:** `GET /api/v1/patients/999`
- **Expected Result:** HTTP 404 Not Found. Message: `Patient not found with ID: 999`.

### TC-PAT-008: Search Patient By Name or Phone (Positive)
- **Request:** `GET /api/v1/patients/search?query=Rahul`
- **Expected Result:** HTTP 200 OK. List of patients matching search substring.

---

## Module 2: Doctor / Referrer Management Test Cases

### TC-DOC-001: Register Doctor With Commission % (Positive)
- **Input Payload:**
  ```json
  {
    "fullName": "Dr. Vikas Mehta",
    "specialization": "Cardiologist",
    "clinicHospitalName": "Max Healthcare",
    "mobile": "9811122233",
    "email": "dr.vikas@maxhealth.com",
    "commissionPercentage": 15.0
  }
  ```
- **Expected Result:** HTTP 201 Created. Auto-assigned `doctorCode` (`DOC-XXXXXXXX`).

### TC-DOC-002: Register Doctor With Invalid Commission Range (Negative)
- **Input Payload:** `commissionPercentage: 150.0`.
- **Expected Result:** HTTP 400 Bad Request. Error message `Commission percentage must be <= 100`.

### TC-DOC-003: Update Doctor Profile (Positive)
- **Request:** `PUT /api/v1/doctors/1`
- **Expected Result:** HTTP 200 OK. Updated fields reflect in database.

---

## Module 3: Test Catalog & Category Test Cases

### TC-TST-001: Create Test Category (Positive)
- **Input Payload:** `{"name": "Histopathology", "description": "Tissue examination"}`
- **Expected Result:** HTTP 201 Created. Category registered in DB.

### TC-TST-002: Create Duplicate Test Category (Negative)
- **Input Payload:** Duplicate category name `Hematology`.
- **Expected Result:** HTTP 400 Bad Request. `Category already exists with name: Hematology`.

### TC-TST-003: Add New Pathology Test Entry (Positive)
- **Input Payload:**
  ```json
  {
    "testName": "HbA1c (Glycated Hemoglobin)",
    "categoryId": 2,
    "price": 600.0,
    "sampleType": "BLOOD",
    "unit": "%",
    "refMinValue": 4.0,
    "refMaxValue": 5.6,
    "normalRangeText": "4.0 - 5.6%"
  }
  ```
- **Expected Result:** HTTP 201 Created. `testCode` (`TST-XXXXXX`) generated.

---

## Module 4: Lab Order & Booking Test Cases

### TC-ORD-001: Create Lab Order With Valid Patient & Tests (Positive)
- **Input Payload:**
  ```json
  {
    "patientId": 1,
    "doctorId": 1,
    "testIds": [1, 2],
    "discountAmount": 50.0,
    "paymentStatus": "PAID"
  }
  ```
- **Expected Result:** HTTP 201 Created.
  - Subtotal: 650.0 (450 + 200)
  - Discount: 50.0
  - Net Amount: 600.0
  - Order Status: `PENDING`
  - Payment Status: `PAID`

### TC-ORD-002: Create Lab Order With Non-existent Patient ID (Negative)
- **Input Payload:** `patientId: 9999`
- **Expected Result:** HTTP 404 Not Found. `Patient not found with ID: 9999`.

### TC-ORD-003: Create Lab Order With Discount Greater Than Subtotal (Boundary/Negative)
- **Input Payload:** Total test cost = 450.0, `discountAmount: 500.0`.
- **Expected Result:** HTTP 400 Bad Request. `Discount amount cannot exceed total bill amount`.

### TC-ORD-004: Update Lab Order Status (Fulfillment Tracking)
- **Request:** `PATCH /api/v1/orders/1/status?status=SAMPLE_COLLECTED`
- **Expected Result:** HTTP 200 OK. `orderStatus` updated to `SAMPLE_COLLECTED`.

---

## Module 5: Lab Results & Report Generation Test Cases

### TC-RPT-001: Enter Normal Test Results (Positive)
- **Input Payload:** Order ID 1 (FBS Test, Range: 70 - 100 mg/dL), `numericValue: 85.0`.
- **Expected Result:** HTTP 201 Created. Result status evaluated automatically as `NORMAL`.

### TC-RPT-002: Enter Abnormal Test Results (Auto-Evaluation Test)
- **Input Payload:** Order ID 1 (FBS Test, Range: 70 - 100 mg/dL), `numericValue: 125.0`.
- **Expected Result:** HTTP 201 Created. Result status evaluated automatically as `ABNORMAL`. Order status updated to `COMPLETED`.

### TC-RPT-003: Enter Critical Value Test Results (Boundary/Critical Test)
- **Input Payload:** FBS Test (Range: 70 - 100 mg/dL), `numericValue: 350.0` (> 50% deviation).
- **Expected Result:** HTTP 201 Created. Result status evaluated automatically as `CRITICAL`.

---

## Module 6: Dashboard & Analytics Test Cases

### TC-DSH-001: Fetch Dashboard Summary Metrics (Positive)
- **Request:** `GET /api/v1/dashboard/summary`
- **Expected Result:** HTTP 200 OK. Returns total counts for patients, doctors, tests, orders, pending orders, completed orders, and calculated revenue.

---

## Module 7: System & Exception Handling Test Cases

### TC-SYS-001: Invalid JSON Payload Body
- **Request:** Send malformed JSON payload `{ "fullName": "Test", }`
- **Expected Result:** HTTP 400 Bad Request. Structured ErrorDetails payload.

### TC-SYS-002: Unsupported HTTP Method
- **Request:** `DELETE /api/v1/dashboard/summary`
- **Expected Result:** HTTP 405 Method Not Allowed.

---

## 11. Automated Test Execution Summary

The repository includes automated unit and integration tests under `src/test/java/com/pathology/`:
- `PatientControllerTest.java` - MVC Layer MockMvc tests.
- `LabOrderServiceTest.java` - Isolated Service unit logic tests with Mockito.
- `LabReportServiceTest.java` - Automated result status classification test cases.
- `PathologyIntegrationTest.java` - Full integration test suite.

**To Run Automated Tests:**
```bash
./mvnw clean test
```
