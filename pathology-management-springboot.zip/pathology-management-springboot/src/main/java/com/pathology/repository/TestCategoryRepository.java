package com.pathology.repository;

import com.pathology.model.TestCategory;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.Optional;

@Repository
public interface TestCategoryRepository extends JpaRepository<TestCategory, Long> {

    Optional<TestCategory> findByNameIgnoreCase(String name);
}
