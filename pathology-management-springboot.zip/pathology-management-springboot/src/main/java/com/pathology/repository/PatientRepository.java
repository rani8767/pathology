package com.pathology.repository;

import com.pathology.model.Patient;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PatientRepository extends JpaRepository<Patient, Long> {

    Optional<Patient> findByPatientCode(String patientCode);

    List<Patient> findByFullNameContainingIgnoreCase(String name);

    List<Patient> findByMobileContaining(String mobile);

    @Query("SELECT p FROM Patient p WHERE LOWER(p.fullName) LIKE LOWER(CONCAT('%', :query, '%')) OR p.mobile LIKE CONCAT('%', :query, '%') OR LOWER(p.patientCode) LIKE LOWER(CONCAT('%', :query, '%'))")
    List<Patient> searchPatients(String query);
}
