package com.pathology.repository;

import com.pathology.model.PathologyTest;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.stereotype.Repository;

import java.util.List;
import java.util.Optional;

@Repository
public interface PathologyTestRepository extends JpaRepository<PathologyTest, Long> {

    Optional<PathologyTest> findByTestCode(String testCode);

    List<PathologyTest> findByCategoryId(Long categoryId);

    List<PathologyTest> findByTestNameContainingIgnoreCase(String name);
}
