package com.pathology.repository;

import com.pathology.model.LabOrder;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.PaymentStatus;
import org.springframework.data.jpa.repository.JpaRepository;
import org.springframework.data.jpa.repository.Query;
import org.springframework.stereotype.Repository;

import java.time.LocalDateTime;
import java.util.List;
import java.util.Optional;

@Repository
public interface LabOrderRepository extends JpaRepository<LabOrder, Long> {

    Optional<LabOrder> findByOrderNumber(String orderNumber);

    List<LabOrder> findByPatientId(Long patientId);

    List<LabOrder> findByOrderStatus(OrderStatus status);

    List<LabOrder> findByPaymentStatus(PaymentStatus paymentStatus);

    @Query("SELECT COUNT(o) FROM LabOrder o WHERE o.orderStatus = :status")
    long countByOrderStatus(OrderStatus status);

    @Query("SELECT COALESCE(SUM(o.netAmount), 0.0) FROM LabOrder o WHERE o.createdAt >= :startDate")
    Double calculateRevenueSince(LocalDateTime startDate);
}
