package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.CategoryDTO;
import com.pathology.dto.PathologyTestRequestDTO;
import com.pathology.dto.PathologyTestResponseDTO;
import com.pathology.service.PathologyTestService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1")
@RequiredArgsConstructor
@Tag(name = "Test Catalog Controller", description = "Endpoints for managing test categories and test master items")
public class PathologyTestController {

    private final PathologyTestService testService;

    @PostMapping("/categories")
    @Operation(summary = "Create test category")
    public ResponseEntity<ApiResponseDTO<CategoryDTO>> createCategory(@Valid @RequestBody CategoryDTO request) {
        CategoryDTO response = testService.createCategory(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Category created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping("/categories")
    @Operation(summary = "Get all test categories")
    public ResponseEntity<ApiResponseDTO<List<CategoryDTO>>> getAllCategories() {
        List<CategoryDTO> categories = testService.getAllCategories();
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched all categories", categories));
    }

    @PostMapping("/tests")
    @Operation(summary = "Create pathology test master entry")
    public ResponseEntity<ApiResponseDTO<PathologyTestResponseDTO>> createTest(@Valid @RequestBody PathologyTestRequestDTO request) {
        PathologyTestResponseDTO response = testService.createTest(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Test created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping("/tests")
    @Operation(summary = "Get all pathology tests")
    public ResponseEntity<ApiResponseDTO<List<PathologyTestResponseDTO>>> getAllTests() {
        List<PathologyTestResponseDTO> tests = testService.getAllTests();
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched all tests", tests));
    }

    @GetMapping("/tests/{id}")
    @Operation(summary = "Get pathology test by ID")
    public ResponseEntity<ApiResponseDTO<PathologyTestResponseDTO>> getTestById(@PathVariable Long id) {
        PathologyTestResponseDTO response = testService.getTestById(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Test retrieved successfully", response));
    }

    @GetMapping("/categories/{categoryId}/tests")
    @Operation(summary = "Get pathology tests by category ID")
    public ResponseEntity<ApiResponseDTO<List<PathologyTestResponseDTO>>> getTestsByCategory(@PathVariable Long categoryId) {
        List<PathologyTestResponseDTO> tests = testService.getTestsByCategoryId(categoryId);
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched tests for category", tests));
    }
}
