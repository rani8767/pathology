package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.PatientRequestDTO;
import com.pathology.dto.PatientResponseDTO;
import com.pathology.service.PatientService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/patients")
@RequiredArgsConstructor
@Tag(name = "Patient Controller", description = "Endpoints for managing patient records")
public class PatientController {

    private final PatientService patientService;

    @PostMapping
    @Operation(summary = "Register a new patient")
    public ResponseEntity<ApiResponseDTO<PatientResponseDTO>> createPatient(@Valid @RequestBody PatientRequestDTO request) {
        PatientResponseDTO response = patientService.createPatient(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Patient registered successfully", response), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all registered patients")
    public ResponseEntity<ApiResponseDTO<List<PatientResponseDTO>>> getAllPatients() {
        List<PatientResponseDTO> patients = patientService.getAllPatients();
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched all patients", patients));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get patient by ID")
    public ResponseEntity<ApiResponseDTO<PatientResponseDTO>> getPatientById(@PathVariable Long id) {
        PatientResponseDTO response = patientService.getPatientById(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Patient retrieved successfully", response));
    }

    @GetMapping("/code/{code}")
    @Operation(summary = "Get patient by Patient Code")
    public ResponseEntity<ApiResponseDTO<PatientResponseDTO>> getPatientByCode(@PathVariable String code) {
        PatientResponseDTO response = patientService.getPatientByCode(code);
        return ResponseEntity.ok(ApiResponseDTO.success("Patient retrieved successfully", response));
    }

    @GetMapping("/search")
    @Operation(summary = "Search patients by name, mobile, or code")
    public ResponseEntity<ApiResponseDTO<List<PatientResponseDTO>>> searchPatients(@RequestParam String query) {
        List<PatientResponseDTO> results = patientService.searchPatients(query);
        return ResponseEntity.ok(ApiResponseDTO.success("Search completed", results));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update patient details")
    public ResponseEntity<ApiResponseDTO<PatientResponseDTO>> updatePatient(@PathVariable Long id, @Valid @RequestBody PatientRequestDTO request) {
        PatientResponseDTO response = patientService.updatePatient(id, request);
        return ResponseEntity.ok(ApiResponseDTO.success("Patient updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete patient record")
    public ResponseEntity<ApiResponseDTO<String>> deletePatient(@PathVariable Long id) {
        patientService.deletePatient(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Patient deleted successfully", "Deleted ID: " + id));
    }
}
