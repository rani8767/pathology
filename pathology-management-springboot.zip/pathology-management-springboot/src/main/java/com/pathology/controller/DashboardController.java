package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.DashboardDTO;
import com.pathology.service.DashboardService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import lombok.RequiredArgsConstructor;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RestController;

@RestController
@RequestMapping("/api/v1/dashboard")
@RequiredArgsConstructor
@Tag(name = "Dashboard Controller", description = "Endpoints for summary analytics and metrics")
public class DashboardController {

    private final DashboardService dashboardService;

    @GetMapping("/summary")
    @Operation(summary = "Get overall pathology dashboard summary")
    public ResponseEntity<ApiResponseDTO<DashboardDTO>> getDashboardSummary() {
        DashboardDTO dto = dashboardService.getDashboardMetrics();
        return ResponseEntity.ok(ApiResponseDTO.success("Dashboard metrics fetched", dto));
    }
}
