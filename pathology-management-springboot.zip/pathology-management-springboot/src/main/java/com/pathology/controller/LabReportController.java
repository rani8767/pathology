package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.LabReportRequestDTO;
import com.pathology.dto.LabReportResponseDTO;
import com.pathology.service.LabReportService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

@RestController
@RequestMapping("/api/v1/reports")
@RequiredArgsConstructor
@Tag(name = "Lab Report Controller", description = "Endpoints for lab report generation, result entry, and approval")
public class LabReportController {

    private final LabReportService reportService;

    @PostMapping
    @Operation(summary = "Enter test results & generate/update lab report")
    public ResponseEntity<ApiResponseDTO<LabReportResponseDTO>> saveReport(@Valid @RequestBody LabReportRequestDTO request) {
        LabReportResponseDTO response = reportService.createOrUpdateReport(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Lab report saved successfully", response), HttpStatus.CREATED);
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get lab report by Report ID")
    public ResponseEntity<ApiResponseDTO<LabReportResponseDTO>> getReportById(@PathVariable Long id) {
        LabReportResponseDTO response = reportService.getReportById(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Lab report retrieved", response));
    }

    @GetMapping("/order/{orderId}")
    @Operation(summary = "Get lab report by Order ID")
    public ResponseEntity<ApiResponseDTO<LabReportResponseDTO>> getReportByOrderId(@PathVariable Long orderId) {
        LabReportResponseDTO response = reportService.getReportByOrderId(orderId);
        return ResponseEntity.ok(ApiResponseDTO.success("Lab report retrieved", response));
    }
}
