package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.DoctorRequestDTO;
import com.pathology.dto.DoctorResponseDTO;
import com.pathology.service.DoctorService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/doctors")
@RequiredArgsConstructor
@Tag(name = "Doctor Controller", description = "Endpoints for managing referring doctors")
public class DoctorController {

    private final DoctorService doctorService;

    @PostMapping
    @Operation(summary = "Register a new referring doctor")
    public ResponseEntity<ApiResponseDTO<DoctorResponseDTO>> createDoctor(@Valid @RequestBody DoctorRequestDTO request) {
        DoctorResponseDTO response = doctorService.createDoctor(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Doctor registered successfully", response), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get list of all doctors")
    public ResponseEntity<ApiResponseDTO<List<DoctorResponseDTO>>> getAllDoctors() {
        List<DoctorResponseDTO> doctors = doctorService.getAllDoctors();
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched all doctors", doctors));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get doctor by ID")
    public ResponseEntity<ApiResponseDTO<DoctorResponseDTO>> getDoctorById(@PathVariable Long id) {
        DoctorResponseDTO response = doctorService.getDoctorById(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Doctor retrieved successfully", response));
    }

    @PutMapping("/{id}")
    @Operation(summary = "Update doctor profile")
    public ResponseEntity<ApiResponseDTO<DoctorResponseDTO>> updateDoctor(@PathVariable Long id, @Valid @RequestBody DoctorRequestDTO request) {
        DoctorResponseDTO response = doctorService.updateDoctor(id, request);
        return ResponseEntity.ok(ApiResponseDTO.success("Doctor updated successfully", response));
    }

    @DeleteMapping("/{id}")
    @Operation(summary = "Delete doctor profile")
    public ResponseEntity<ApiResponseDTO<String>> deleteDoctor(@PathVariable Long id) {
        doctorService.deleteDoctor(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Doctor deleted successfully", "Deleted ID: " + id));
    }
}
