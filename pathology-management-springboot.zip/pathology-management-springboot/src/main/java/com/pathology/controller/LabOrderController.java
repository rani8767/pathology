package com.pathology.controller;

import com.pathology.dto.ApiResponseDTO;
import com.pathology.dto.LabOrderRequestDTO;
import com.pathology.dto.LabOrderResponseDTO;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.PaymentStatus;
import com.pathology.service.LabOrderService;
import io.swagger.v3.oas.annotations.Operation;
import io.swagger.v3.oas.annotations.tags.Tag;
import jakarta.validation.Valid;
import lombok.RequiredArgsConstructor;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.List;

@RestController
@RequestMapping("/api/v1/orders")
@RequiredArgsConstructor
@Tag(name = "Lab Order Controller", description = "Endpoints for managing lab bookings and test orders")
public class LabOrderController {

    private final LabOrderService orderService;

    @PostMapping
    @Operation(summary = "Create a new lab order / booking")
    public ResponseEntity<ApiResponseDTO<LabOrderResponseDTO>> createOrder(@Valid @RequestBody LabOrderRequestDTO request) {
        LabOrderResponseDTO response = orderService.createOrder(request);
        return new ResponseEntity<>(ApiResponseDTO.success("Order created successfully", response), HttpStatus.CREATED);
    }

    @GetMapping
    @Operation(summary = "Get all lab orders")
    public ResponseEntity<ApiResponseDTO<List<LabOrderResponseDTO>>> getAllOrders() {
        List<LabOrderResponseDTO> orders = orderService.getAllOrders();
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched all orders", orders));
    }

    @GetMapping("/{id}")
    @Operation(summary = "Get order details by Order ID")
    public ResponseEntity<ApiResponseDTO<LabOrderResponseDTO>> getOrderById(@PathVariable Long id) {
        LabOrderResponseDTO response = orderService.getOrderById(id);
        return ResponseEntity.ok(ApiResponseDTO.success("Order retrieved successfully", response));
    }

    @GetMapping("/patient/{patientId}")
    @Operation(summary = "Get lab orders for a specific patient")
    public ResponseEntity<ApiResponseDTO<List<LabOrderResponseDTO>>> getOrdersByPatient(@PathVariable Long patientId) {
        List<LabOrderResponseDTO> orders = orderService.getOrdersByPatientId(patientId);
        return ResponseEntity.ok(ApiResponseDTO.success("Fetched patient orders", orders));
    }

    @PatchMapping("/{id}/status")
    @Operation(summary = "Update lab order sample/fulfillment status")
    public ResponseEntity<ApiResponseDTO<LabOrderResponseDTO>> updateOrderStatus(@PathVariable Long id, @RequestParam OrderStatus status) {
        LabOrderResponseDTO response = orderService.updateOrderStatus(id, status);
        return ResponseEntity.ok(ApiResponseDTO.success("Order status updated successfully", response));
    }

    @PatchMapping("/{id}/payment")
    @Operation(summary = "Update lab order payment status")
    public ResponseEntity<ApiResponseDTO<LabOrderResponseDTO>> updatePaymentStatus(@PathVariable Long id, @RequestParam PaymentStatus status) {
        LabOrderResponseDTO response = orderService.updatePaymentStatus(id, status);
        return ResponseEntity.ok(ApiResponseDTO.success("Payment status updated successfully", response));
    }
}
