package com.pathology.model;

import jakarta.persistence.*;
import lombok.*;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;

@Entity
@Table(name = "lab_reports")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class LabReport {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @Column(name = "report_number", unique = true, nullable = false)
    private String reportNumber;

    @OneToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "order_id", nullable = false, unique = true)
    private LabOrder order;

    @OneToMany(mappedBy = "report", cascade = CascadeType.ALL, orphanRemoval = true, fetch = FetchType.EAGER)
    @Builder.Default
    private List<ReportResultItem> results = new ArrayList<>();

    @Column(name = "verified_by")
    private String verifiedBy;

    @Column(name = "is_approved")
    private Boolean isApproved;

    @Column(name = "clinical_notes")
    private String clinicalNotes;

    @Column(name = "reported_at")
    private LocalDateTime reportedAt;

    @Column(name = "created_at", nullable = false, updatable = false)
    private LocalDateTime createdAt;

    @PrePersist
    protected void onCreate() {
        this.createdAt = LocalDateTime.now();
        if (this.reportedAt == null) {
            this.reportedAt = LocalDateTime.now();
        }
        if (this.isApproved == null) {
            this.isApproved = false;
        }
    }

    public void addResultItem(ReportResultItem resultItem) {
        results.add(resultItem);
        resultItem.setReport(this);
    }
}
