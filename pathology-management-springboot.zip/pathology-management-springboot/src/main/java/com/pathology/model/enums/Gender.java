package com.pathology.model.enums;

public enum Gender {
    MALE,
    FEMALE,
    OTHER
}
