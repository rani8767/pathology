package com.pathology.model;

import com.pathology.model.enums.ResultStatus;
import jakarta.persistence.*;
import lombok.*;

@Entity
@Table(name = "report_result_items")
@Getter
@Setter
@NoArgsConstructor
@AllArgsConstructor
@Builder
public class ReportResultItem {

    @Id
    @GeneratedValue(strategy = GenerationType.IDENTITY)
    private Long id;

    @ManyToOne(fetch = FetchType.LAZY)
    @JoinColumn(name = "report_id", nullable = false)
    private LabReport report;

    @ManyToOne(fetch = FetchType.EAGER)
    @JoinColumn(name = "test_id", nullable = false)
    private PathologyTest test;

    @Column(name = "result_value")
    private String resultValue;

    @Column(name = "numeric_value")
    private Double numericValue;

    @Column(name = "unit")
    private String unit;

    @Column(name = "normal_range")
    private String normalRange;

    @Enumerated(EnumType.STRING)
    @Column(name = "result_status", nullable = false)
    private ResultStatus resultStatus;

    @Column(name = "remarks")
    private String remarks;
}
