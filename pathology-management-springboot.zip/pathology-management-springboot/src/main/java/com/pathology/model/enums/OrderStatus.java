package com.pathology.model.enums;

public enum OrderStatus {
    PENDING,
    SAMPLE_COLLECTED,
    IN_LAB,
    COMPLETED,
    CANCELLED
}
