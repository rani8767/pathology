package com.pathology.model.enums;

public enum ResultStatus {
    NORMAL,
    ABNORMAL,
    CRITICAL
}
