package com.pathology.model.enums;

public enum PaymentStatus {
    UNPAID,
    PARTIAL,
    PAID
}
