package com.pathology.model.enums;

public enum SampleType {
    BLOOD,
    URINE,
    SERUM,
    PLASMA,
    SPUTUM,
    STOOL,
    SWAB,
    TISSUE,
    OTHER
}
