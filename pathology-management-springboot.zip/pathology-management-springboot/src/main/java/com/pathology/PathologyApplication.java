package com.pathology;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;
import org.springframework.boot.autoconfigure.domain.EntityScan;
import org.springframework.data.jpa.repository.config.EnableJpaRepositories;

@SpringBootApplication
@EntityScan(basePackages = "com.pathology.model")
@EnableJpaRepositories(basePackages = "com.pathology.repository")
public class PathologyApplication {

    public static void main(String[] args) {
        SpringApplication.run(PathologyApplication.class, args);
    }
}
