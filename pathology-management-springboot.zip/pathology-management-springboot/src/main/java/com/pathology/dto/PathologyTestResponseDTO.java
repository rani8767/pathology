package com.pathology.dto;

import com.pathology.model.enums.SampleType;
import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class PathologyTestResponseDTO {
    private Long id;
    private String testCode;
    private String testName;
    private Long categoryId;
    private String categoryName;
    private Double price;
    private SampleType sampleType;
    private String unit;
    private Double refMinValue;
    private Double refMaxValue;
    private String normalRangeText;
}
