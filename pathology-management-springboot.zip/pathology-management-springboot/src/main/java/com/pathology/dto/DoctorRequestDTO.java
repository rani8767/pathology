package com.pathology.dto;

import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class DoctorRequestDTO {

    @NotBlank(message = "Doctor name is required")
    private String fullName;

    private String specialization;

    private String clinicHospitalName;

    @NotBlank(message = "Mobile number is required")
    @Pattern(regexp = "^[0-9]{10,15}$", message = "Mobile number must be between 10 and 15 digits")
    private String mobile;

    @Email(message = "Invalid email format")
    private String email;

    @Min(value = 0, message = "Commission percentage must be >= 0")
    @Max(value = 100, message = "Commission percentage must be <= 100")
    private Double commissionPercentage;
}
