package com.pathology.dto;

import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.PaymentStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class LabOrderResponseDTO {
    private Long id;
    private String orderNumber;
    private Long patientId;
    private String patientName;
    private String patientCode;
    private Long doctorId;
    private String doctorName;
    private List<OrderItemDTO> items;
    private Double totalAmount;
    private Double discountAmount;
    private Double netAmount;
    private OrderStatus orderStatus;
    private PaymentStatus paymentStatus;
    private LocalDateTime createdAt;

    @Data
    @Builder
    public static class OrderItemDTO {
        private Long testId;
        private String testCode;
        private String testName;
        private Double price;
    }
}
