package com.pathology.dto;

import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class DoctorResponseDTO {
    private Long id;
    private String doctorCode;
    private String fullName;
    private String specialization;
    private String clinicHospitalName;
    private String mobile;
    private String email;
    private Double commissionPercentage;
    private LocalDateTime createdAt;
}
