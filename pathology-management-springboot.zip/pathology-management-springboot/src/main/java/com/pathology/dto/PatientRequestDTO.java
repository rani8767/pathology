package com.pathology.dto;

import com.pathology.model.enums.Gender;
import jakarta.validation.constraints.*;
import lombok.Data;

@Data
public class PatientRequestDTO {

    @NotBlank(message = "Full name is required")
    private String fullName;

    @NotNull(message = "Age is required")
    @Min(value = 0, message = "Age must be >= 0")
    @Max(value = 150, message = "Age must be <= 150")
    private Integer age;

    @NotNull(message = "Gender is required")
    private Gender gender;

    @NotBlank(message = "Mobile number is required")
    @Pattern(regexp = "^[0-9]{10,15}$", message = "Mobile number must be between 10 and 15 digits")
    private String mobile;

    @Email(message = "Invalid email format")
    private String email;

    private String address;

    private String bloodGroup;
}
