package com.pathology.dto;

import com.pathology.model.enums.SampleType;
import jakarta.validation.constraints.Min;
import jakarta.validation.constraints.NotBlank;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

@Data
public class PathologyTestRequestDTO {

    @NotBlank(message = "Test name is required")
    private String testName;

    @NotNull(message = "Category ID is required")
    private Long categoryId;

    @NotNull(message = "Price is required")
    @Min(value = 0, message = "Price must be >= 0")
    private Double price;

    @NotNull(message = "Sample type is required")
    private SampleType sampleType;

    private String unit;
    private Double refMinValue;
    private Double refMaxValue;
    private String normalRangeText;
}
