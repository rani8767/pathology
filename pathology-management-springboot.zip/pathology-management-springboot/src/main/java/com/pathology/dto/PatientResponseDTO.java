package com.pathology.dto;

import com.pathology.model.enums.Gender;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;

@Data
@Builder
public class PatientResponseDTO {
    private Long id;
    private String patientCode;
    private String fullName;
    private Integer age;
    private Gender gender;
    private String mobile;
    private String email;
    private String address;
    private String bloodGroup;
    private LocalDateTime createdAt;
}
