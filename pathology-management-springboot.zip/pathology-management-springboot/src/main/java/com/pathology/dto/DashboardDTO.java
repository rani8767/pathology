package com.pathology.dto;

import lombok.Builder;
import lombok.Data;

@Data
@Builder
public class DashboardDTO {
    private long totalPatients;
    private long totalDoctors;
    private long totalTests;
    private long totalOrders;
    private long pendingOrders;
    private long completedOrders;
    private Double totalRevenue;
}
