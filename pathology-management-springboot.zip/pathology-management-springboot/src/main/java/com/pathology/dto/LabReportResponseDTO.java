package com.pathology.dto;

import com.pathology.model.enums.ResultStatus;
import lombok.Builder;
import lombok.Data;

import java.time.LocalDateTime;
import java.util.List;

@Data
@Builder
public class LabReportResponseDTO {
    private Long id;
    private String reportNumber;
    private Long orderId;
    private String orderNumber;
    private String patientName;
    private String patientCode;
    private String doctorName;
    private String verifiedBy;
    private Boolean isApproved;
    private String clinicalNotes;
    private LocalDateTime reportedAt;
    private List<ResultItemDTO> results;

    @Data
    @Builder
    public static class ResultItemDTO {
        private Long testId;
        private String testCode;
        private String testName;
        private String resultValue;
        private Double numericValue;
        private String unit;
        private String normalRange;
        private ResultStatus resultStatus;
        private String remarks;
    }
}
