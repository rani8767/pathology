package com.pathology.dto;

import com.pathology.model.enums.PaymentStatus;
import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class LabOrderRequestDTO {

    @NotNull(message = "Patient ID is required")
    private Long patientId;

    private Long doctorId;

    @NotEmpty(message = "At least one test ID must be selected")
    private List<Long> testIds;

    private Double discountAmount;

    private PaymentStatus paymentStatus;
}
