package com.pathology.dto;

import jakarta.validation.constraints.NotEmpty;
import jakarta.validation.constraints.NotNull;
import lombok.Data;

import java.util.List;

@Data
public class LabReportRequestDTO {

    @NotNull(message = "Order ID is required")
    private Long orderId;

    @NotEmpty(message = "Result items are required")
    private List<ResultInputDTO> results;

    private String verifiedBy;
    private Boolean isApproved;
    private String clinicalNotes;

    @Data
    public static class ResultInputDTO {
        @NotNull(message = "Test ID is required")
        private Long testId;

        private String resultValue;
        private Double numericValue;
        private String remarks;
    }
}
