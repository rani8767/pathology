package com.pathology.service;

import com.pathology.dto.CategoryDTO;
import com.pathology.dto.PathologyTestRequestDTO;
import com.pathology.dto.PathologyTestResponseDTO;
import com.pathology.exception.BadRequestException;
import com.pathology.exception.ResourceNotFoundException;
import com.pathology.model.PathologyTest;
import com.pathology.model.TestCategory;
import com.pathology.repository.PathologyTestRepository;
import com.pathology.repository.TestCategoryRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class PathologyTestService {

    private final PathologyTestRepository testRepository;
    private final TestCategoryRepository categoryRepository;

    @Transactional
    public CategoryDTO createCategory(CategoryDTO request) {
        if (categoryRepository.findByNameIgnoreCase(request.getName()).isPresent()) {
            throw new BadRequestException("Category already exists with name: " + request.getName());
        }
        TestCategory category = TestCategory.builder()
                .name(request.getName())
                .description(request.getDescription())
                .build();
        TestCategory saved = categoryRepository.save(category);
        return CategoryDTO.builder()
                .id(saved.getId())
                .name(saved.getName())
                .description(saved.getDescription())
                .build();
    }

    public List<CategoryDTO> getAllCategories() {
        return categoryRepository.findAll().stream()
                .map(c -> CategoryDTO.builder()
                        .id(c.getId())
                        .name(c.getName())
                        .description(c.getDescription())
                        .build())
                .collect(Collectors.toList());
    }

    @Transactional
    public PathologyTestResponseDTO createTest(PathologyTestRequestDTO request) {
        TestCategory category = categoryRepository.findById(request.getCategoryId())
                .orElseThrow(() -> new ResourceNotFoundException("Category not found with ID: " + request.getCategoryId()));

        String code = "TST-" + UUID.randomUUID().toString().substring(0, 6).toUpperCase();
        PathologyTest test = PathologyTest.builder()
                .testCode(code)
                .testName(request.getTestName())
                .category(category)
                .price(request.getPrice())
                .sampleType(request.getSampleType())
                .unit(request.getUnit())
                .refMinValue(request.getRefMinValue())
                .refMaxValue(request.getRefMaxValue())
                .normalRangeText(request.getNormalRangeText())
                .build();

        PathologyTest saved = testRepository.save(test);
        return mapToDTO(saved);
    }

    public List<PathologyTestResponseDTO> getAllTests() {
        return testRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public PathologyTestResponseDTO getTestById(Long id) {
        PathologyTest test = testRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Test not found with ID: " + id));
        return mapToDTO(test);
    }

    public List<PathologyTestResponseDTO> getTestsByCategoryId(Long categoryId) {
        return testRepository.findByCategoryId(categoryId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public PathologyTestResponseDTO mapToDTO(PathologyTest test) {
        return PathologyTestResponseDTO.builder()
                .id(test.getId())
                .testCode(test.getTestCode())
                .testName(test.getTestName())
                .categoryId(test.getCategory().getId())
                .categoryName(test.getCategory().getName())
                .price(test.getPrice())
                .sampleType(test.getSampleType())
                .unit(test.getUnit())
                .refMinValue(test.getRefMinValue())
                .refMaxValue(test.getRefMaxValue())
                .normalRangeText(test.getNormalRangeText())
                .build();
    }
}
