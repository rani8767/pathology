package com.pathology.service;

import com.pathology.dto.DoctorRequestDTO;
import com.pathology.dto.DoctorResponseDTO;
import com.pathology.exception.ResourceNotFoundException;
import com.pathology.model.Doctor;
import com.pathology.repository.DoctorRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class DoctorService {

    private final DoctorRepository doctorRepository;

    @Transactional
    public DoctorResponseDTO createDoctor(DoctorRequestDTO request) {
        String code = "DOC-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();
        Doctor doctor = Doctor.builder()
                .doctorCode(code)
                .fullName(request.getFullName())
                .specialization(request.getSpecialization())
                .clinicHospitalName(request.getClinicHospitalName())
                .mobile(request.getMobile())
                .email(request.getEmail())
                .commissionPercentage(request.getCommissionPercentage() != null ? request.getCommissionPercentage() : 0.0)
                .build();

        Doctor saved = doctorRepository.save(doctor);
        return mapToDTO(saved);
    }

    public List<DoctorResponseDTO> getAllDoctors() {
        return doctorRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public DoctorResponseDTO getDoctorById(Long id) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + id));
        return mapToDTO(doctor);
    }

    @Transactional
    public DoctorResponseDTO updateDoctor(Long id, DoctorRequestDTO request) {
        Doctor doctor = doctorRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + id));

        doctor.setFullName(request.getFullName());
        doctor.setSpecialization(request.getSpecialization());
        doctor.setClinicHospitalName(request.getClinicHospitalName());
        doctor.setMobile(request.getMobile());
        doctor.setEmail(request.getEmail());
        if (request.getCommissionPercentage() != null) {
            doctor.setCommissionPercentage(request.getCommissionPercentage());
        }

        Doctor updated = doctorRepository.save(doctor);
        return mapToDTO(updated);
    }

    @Transactional
    public void deleteDoctor(Long id) {
        if (!doctorRepository.existsById(id)) {
            throw new ResourceNotFoundException("Doctor not found with ID: " + id);
        }
        doctorRepository.deleteById(id);
    }

    public DoctorResponseDTO mapToDTO(Doctor doctor) {
        return DoctorResponseDTO.builder()
                .id(doctor.getId())
                .doctorCode(doctor.getDoctorCode())
                .fullName(doctor.getFullName())
                .specialization(doctor.getSpecialization())
                .clinicHospitalName(doctor.getClinicHospitalName())
                .mobile(doctor.getMobile())
                .email(doctor.getEmail())
                .commissionPercentage(doctor.getCommissionPercentage())
                .createdAt(doctor.getCreatedAt())
                .build();
    }
}
