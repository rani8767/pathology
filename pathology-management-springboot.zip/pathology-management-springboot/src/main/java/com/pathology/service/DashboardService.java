package com.pathology.service;

import com.pathology.dto.DashboardDTO;
import com.pathology.model.enums.OrderStatus;
import com.pathology.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;

import java.time.LocalDateTime;

@Service
@RequiredArgsConstructor
public class DashboardService {

    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final PathologyTestRepository testRepository;
    private final LabOrderRepository orderRepository;

    public DashboardDTO getDashboardMetrics() {
        long totalPatients = patientRepository.count();
        long totalDoctors = doctorRepository.count();
        long totalTests = testRepository.count();
        long totalOrders = orderRepository.count();
        long pendingOrders = orderRepository.countByOrderStatus(OrderStatus.PENDING);
        long completedOrders = orderRepository.countByOrderStatus(OrderStatus.COMPLETED);
        Double revenue = orderRepository.calculateRevenueSince(LocalDateTime.now().minusYears(100));

        return DashboardDTO.builder()
                .totalPatients(totalPatients)
                .totalDoctors(totalDoctors)
                .totalTests(totalTests)
                .totalOrders(totalOrders)
                .pendingOrders(pendingOrders)
                .completedOrders(completedOrders)
                .totalRevenue(revenue != null ? revenue : 0.0)
                .build();
    }
}
