package com.pathology.service;

import com.pathology.dto.LabOrderRequestDTO;
import com.pathology.dto.LabOrderResponseDTO;
import com.pathology.exception.BadRequestException;
import com.pathology.exception.ResourceNotFoundException;
import com.pathology.model.*;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.PaymentStatus;
import com.pathology.repository.*;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.util.ArrayList;
import java.util.List;
import java.util.UUID;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LabOrderService {

    private final LabOrderRepository orderRepository;
    private final PatientRepository patientRepository;
    private final DoctorRepository doctorRepository;
    private final PathologyTestRepository testRepository;

    @Transactional
    public LabOrderResponseDTO createOrder(LabOrderRequestDTO request) {
        Patient patient = patientRepository.findById(request.getPatientId())
                .orElseThrow(() -> new ResourceNotFoundException("Patient not found with ID: " + request.getPatientId()));

        Doctor doctor = null;
        if (request.getDoctorId() != null) {
            doctor = doctorRepository.findById(request.getDoctorId())
                    .orElseThrow(() -> new ResourceNotFoundException("Doctor not found with ID: " + request.getDoctorId()));
        }

        if (request.getTestIds() == null || request.getTestIds().isEmpty()) {
            throw new BadRequestException("At least one test must be selected for the order");
        }

        List<PathologyTest> selectedTests = testRepository.findAllById(request.getTestIds());
        if (selectedTests.size() != request.getTestIds().size()) {
            throw new BadRequestException("One or more invalid test IDs provided");
        }

        double totalAmount = selectedTests.stream().mapToDouble(PathologyTest::getPrice).sum();
        double discount = request.getDiscountAmount() != null ? request.getDiscountAmount() : 0.0;
        if (discount > totalAmount) {
            throw new BadRequestException("Discount amount cannot exceed total bill amount");
        }
        double netAmount = totalAmount - discount;

        String orderNum = "ORD-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase();

        LabOrder order = LabOrder.builder()
                .orderNumber(orderNum)
                .patient(patient)
                .referringDoctor(doctor)
                .totalAmount(totalAmount)
                .discountAmount(discount)
                .netAmount(netAmount)
                .orderStatus(OrderStatus.PENDING)
                .paymentStatus(request.getPaymentStatus() != null ? request.getPaymentStatus() : PaymentStatus.UNPAID)
                .items(new ArrayList<>())
                .build();

        for (PathologyTest test : selectedTests) {
            OrderItem item = OrderItem.builder()
                    .test(test)
                    .price(test.getPrice())
                    .build();
            order.addItem(item);
        }

        LabOrder saved = orderRepository.save(order);
        return mapToDTO(saved);
    }

    public List<LabOrderResponseDTO> getAllOrders() {
        return orderRepository.findAll().stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    public LabOrderResponseDTO getOrderById(Long id) {
        LabOrder order = orderRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + id));
        return mapToDTO(order);
    }

    public List<LabOrderResponseDTO> getOrdersByPatientId(Long patientId) {
        return orderRepository.findByPatientId(patientId).stream()
                .map(this::mapToDTO)
                .collect(Collectors.toList());
    }

    @Transactional
    public LabOrderResponseDTO updateOrderStatus(Long orderId, OrderStatus status) {
        LabOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));
        order.setOrderStatus(status);
        LabOrder updated = orderRepository.save(order);
        return mapToDTO(updated);
    }

    @Transactional
    public LabOrderResponseDTO updatePaymentStatus(Long orderId, PaymentStatus paymentStatus) {
        LabOrder order = orderRepository.findById(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + orderId));
        order.setPaymentStatus(paymentStatus);
        LabOrder updated = orderRepository.save(order);
        return mapToDTO(updated);
    }

    public LabOrderResponseDTO mapToDTO(LabOrder order) {
        List<LabOrderResponseDTO.OrderItemDTO> itemDTOs = order.getItems().stream()
                .map(item -> LabOrderResponseDTO.OrderItemDTO.builder()
                        .testId(item.getTest().getId())
                        .testCode(item.getTest().getTestCode())
                        .testName(item.getTest().getTestName())
                        .price(item.getPrice())
                        .build())
                .collect(Collectors.toList());

        return LabOrderResponseDTO.builder()
                .id(order.getId())
                .orderNumber(order.getOrderNumber())
                .patientId(order.getPatient().getId())
                .patientName(order.getPatient().getFullName())
                .patientCode(order.getPatient().getPatientCode())
                .doctorId(order.getReferringDoctor() != null ? order.getReferringDoctor().getId() : null)
                .doctorName(order.getReferringDoctor() != null ? order.getReferringDoctor().getFullName() : null)
                .items(itemDTOs)
                .totalAmount(order.getTotalAmount())
                .discountAmount(order.getDiscountAmount())
                .netAmount(order.getNetAmount())
                .orderStatus(order.getOrderStatus())
                .paymentStatus(order.getPaymentStatus())
                .createdAt(order.getCreatedAt())
                .build();
    }
}
