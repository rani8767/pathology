package com.pathology.service;

import com.pathology.dto.LabReportRequestDTO;
import com.pathology.dto.LabReportResponseDTO;
import com.pathology.exception.BadRequestException;
import com.pathology.exception.ResourceNotFoundException;
import com.pathology.model.*;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.ResultStatus;
import com.pathology.repository.LabOrderRepository;
import com.pathology.repository.LabReportRepository;
import com.pathology.repository.PathologyTestRepository;
import lombok.RequiredArgsConstructor;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import java.time.LocalDateTime;
import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.UUID;
import java.util.function.Function;
import java.util.stream.Collectors;

@Service
@RequiredArgsConstructor
public class LabReportService {

    private final LabReportRepository reportRepository;
    private final LabOrderRepository orderRepository;
    private final PathologyTestRepository testRepository;

    @Transactional
    public LabReportResponseDTO createOrUpdateReport(LabReportRequestDTO request) {
        LabOrder order = orderRepository.findById(request.getOrderId())
                .orElseThrow(() -> new ResourceNotFoundException("Order not found with ID: " + request.getOrderId()));

        LabReport report = reportRepository.findByOrderId(order.getId())
                .orElseGet(() -> LabReport.builder()
                        .reportNumber("RPT-" + UUID.randomUUID().toString().substring(0, 8).toUpperCase())
                        .order(order)
                        .results(new ArrayList<>())
                        .build());

        report.setVerifiedBy(request.getVerifiedBy() != null ? request.getVerifiedBy() : "Pathologist");
        report.setIsApproved(request.getIsApproved() != null ? request.getIsApproved() : false);
        report.setClinicalNotes(request.getClinicalNotes());
        report.setReportedAt(LocalDateTime.now());

        Map<Long, LabReportRequestDTO.ResultInputDTO> resultInputMap = request.getResults().stream()
                .collect(Collectors.toMap(LabReportRequestDTO.ResultInputDTO::getTestId, Function.identity(), (a, b) -> b));

        report.getResults().clear();

        for (OrderItem orderItem : order.getItems()) {
            PathologyTest test = orderItem.getTest();
            LabReportRequestDTO.ResultInputDTO input = resultInputMap.get(test.getId());

            String val = input != null ? input.getResultValue() : null;
            Double numVal = input != null ? input.getNumericValue() : null;
            String remarks = input != null ? input.getRemarks() : null;

            ResultStatus status = evaluateResultStatus(test, numVal, val);

            String normalRange = test.getNormalRangeText();
            if (normalRange == null && test.getRefMinValue() != null && test.getRefMaxValue() != null) {
                normalRange = test.getRefMinValue() + " - " + test.getRefMaxValue();
            }

            ReportResultItem item = ReportResultItem.builder()
                    .report(report)
                    .test(test)
                    .resultValue(val)
                    .numericValue(numVal)
                    .unit(test.getUnit())
                    .normalRange(normalRange)
                    .resultStatus(status)
                    .remarks(remarks)
                    .build();

            report.addResultItem(item);
        }

        LabReport saved = reportRepository.save(report);

        // Update order status to COMPLETED if approved or results entered
        order.setOrderStatus(OrderStatus.COMPLETED);
        orderRepository.save(order);

        return mapToDTO(saved);
    }

    public LabReportResponseDTO getReportById(Long id) {
        LabReport report = reportRepository.findById(id)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found with ID: " + id));
        return mapToDTO(report);
    }

    public LabReportResponseDTO getReportByOrderId(Long orderId) {
        LabReport report = reportRepository.findByOrderId(orderId)
                .orElseThrow(() -> new ResourceNotFoundException("Report not found for Order ID: " + orderId));
        return mapToDTO(report);
    }

    private ResultStatus evaluateResultStatus(PathologyTest test, Double numVal, String textVal) {
        if (numVal != null && test.getRefMinValue() != null && test.getRefMaxValue() != null) {
            if (numVal < test.getRefMinValue() || numVal > test.getRefMaxValue()) {
                double diffPercent = 0.0;
                if (numVal < test.getRefMinValue()) {
                    diffPercent = (test.getRefMinValue() - numVal) / test.getRefMinValue();
                } else {
                    diffPercent = (numVal - test.getRefMaxValue()) / test.getRefMaxValue();
                }
                return diffPercent > 0.5 ? ResultStatus.CRITICAL : ResultStatus.ABNORMAL;
            }
            return ResultStatus.NORMAL;
        }
        return ResultStatus.NORMAL;
    }

    public LabReportResponseDTO mapToDTO(LabReport report) {
        List<LabReportResponseDTO.ResultItemDTO> resultDTOs = report.getResults().stream()
                .map(item -> LabReportResponseDTO.ResultItemDTO.builder()
                        .testId(item.getTest().getId())
                        .testCode(item.getTest().getTestCode())
                        .testName(item.getTest().getTestName())
                        .resultValue(item.getResultValue())
                        .numericValue(item.getNumericValue())
                        .unit(item.getUnit())
                        .normalRange(item.getNormalRange())
                        .resultStatus(item.getResultStatus())
                        .remarks(item.getRemarks())
                        .build())
                .collect(Collectors.toList());

        return LabReportResponseDTO.builder()
                .id(report.getId())
                .reportNumber(report.getReportNumber())
                .orderId(report.getOrder().getId())
                .orderNumber(report.getOrder().getOrderNumber())
                .patientName(report.getOrder().getPatient().getFullName())
                .patientCode(report.getOrder().getPatient().getPatientCode())
                .doctorName(report.getOrder().getReferringDoctor() != null ? report.getOrder().getReferringDoctor().getFullName() : "N/A")
                .verifiedBy(report.getVerifiedBy())
                .isApproved(report.getIsApproved())
                .clinicalNotes(report.getClinicalNotes())
                .reportedAt(report.getReportedAt())
                .results(resultDTOs)
                .build();
    }
}
