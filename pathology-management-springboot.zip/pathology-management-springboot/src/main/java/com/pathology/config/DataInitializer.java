package com.pathology.config;

import com.pathology.dto.*;
import com.pathology.model.enums.Gender;
import com.pathology.model.enums.PaymentStatus;
import com.pathology.model.enums.SampleType;
import com.pathology.service.*;
import lombok.RequiredArgsConstructor;
import lombok.extern.slf4j.Slf4j;
import org.springframework.boot.CommandLineRunner;
import org.springframework.stereotype.Component;

import java.util.List;

@Component
@RequiredArgsConstructor
@Slf4j
public class DataInitializer implements CommandLineRunner {

    private final PatientService patientService;
    private final DoctorService doctorService;
    private final PathologyTestService testService;
    private final LabOrderService orderService;
    private final LabReportService reportService;

    @Override
    public void run(String... args) throws Exception {
        log.info("Checking initial pathology database records...");
        if (!patientService.getAllPatients().isEmpty()) {
            log.info("Database already seeded. Skipping initialization.");
            return;
        }

        log.info("Seeding initial demo data for Pathology Management System...");

        // 1. Create Categories
        CategoryDTO cat1 = testService.createCategory(CategoryDTO.builder().name("Hematology").description("Blood cell count & coagulation tests").build());
        CategoryDTO cat2 = testService.createCategory(CategoryDTO.builder().name("Biochemistry").description("Blood glucose, lipids, kidney, liver profiles").build());
        CategoryDTO cat3 = testService.createCategory(CategoryDTO.builder().name("Microbiology").description("Bacterial & fungal culture tests").build());
        CategoryDTO cat4 = testService.createCategory(CategoryDTO.builder().name("Serology & Immunology").description("Thyroid, antibody, antigen screening").build());

        // 2. Create Pathology Tests
        PathologyTestRequestDTO cbc = new PathologyTestRequestDTO();
        cbc.setTestName("Complete Blood Count (CBC)");
        cbc.setCategoryId(cat1.getId());
        cbc.setPrice(450.0);
        cbc.setSampleType(SampleType.BLOOD);
        cbc.setUnit("g/dL");
        cbc.setRefMinValue(13.0);
        cbc.setRefMaxValue(17.0);
        cbc.setNormalRangeText("13.0 - 17.0 g/dL");
        PathologyTestResponseDTO testCbc = testService.createTest(cbc);

        PathologyTestRequestDTO fbg = new PathologyTestRequestDTO();
        fbg.setTestName("Fasting Blood Sugar (FBS)");
        fbg.setCategoryId(cat2.getId());
        fbg.setPrice(200.0);
        fbg.setSampleType(SampleType.BLOOD);
        fbg.setUnit("mg/dL");
        fbg.setRefMinValue(70.0);
        fbg.setRefMaxValue(100.0);
        fbg.setNormalRangeText("70 - 100 mg/dL");
        PathologyTestResponseDTO testFbg = testService.createTest(fbg);

        PathologyTestRequestDTO lipid = new PathologyTestRequestDTO();
        lipid.setTestName("Lipid Profile (Total Cholesterol)");
        lipid.setCategoryId(cat2.getId());
        lipid.setPrice(800.0);
        lipid.setSampleType(SampleType.BLOOD);
        lipid.setUnit("mg/dL");
        lipid.setRefMinValue(125.0);
        lipid.setRefMaxValue(200.0);
        lipid.setNormalRangeText("125 - 200 mg/dL");
        PathologyTestResponseDTO testLipid = testService.createTest(lipid);

        PathologyTestRequestDTO tsh = new PathologyTestRequestDTO();
        tsh.setTestName("Thyroid Stimulating Hormone (TSH)");
        tsh.setCategoryId(cat4.getId());
        tsh.setPrice(550.0);
        tsh.setSampleType(SampleType.SERUM);
        tsh.setUnit("uIU/mL");
        tsh.setRefMinValue(0.4);
        tsh.setRefMaxValue(4.0);
        tsh.setNormalRangeText("0.4 - 4.0 uIU/mL");
        PathologyTestResponseDTO testTsh = testService.createTest(tsh);

        // 3. Create Doctors
        DoctorRequestDTO docReq1 = new DoctorRequestDTO();
        docReq1.setFullName("Dr. Rajesh Sharma");
        docReq1.setSpecialization("General Physician");
        docReq1.setClinicHospitalName("Apex Heart & Care Hospital");
        docReq1.setMobile("9876543210");
        docReq1.setEmail("dr.rajesh@apexcare.com");
        docReq1.setCommissionPercentage(10.0);
        DoctorResponseDTO doc1 = doctorService.createDoctor(docReq1);

        DoctorRequestDTO docReq2 = new DoctorRequestDTO();
        docReq2.setFullName("Dr. Ananya Verma");
        docReq2.setSpecialization("Endocrinologist");
        docReq2.setClinicHospitalName("City Diagnostic & Clinic");
        docReq2.setMobile("9812345678");
        docReq2.setEmail("ananya.verma@citydiag.org");
        docReq2.setCommissionPercentage(12.0);
        DoctorResponseDTO doc2 = doctorService.createDoctor(docReq2);

        // 4. Create Patients
        PatientRequestDTO patReq1 = new PatientRequestDTO();
        patReq1.setFullName("Amit Kumar");
        patReq1.setAge(35);
        patReq1.setGender(Gender.MALE);
        patReq1.setMobile("9988776655");
        patReq1.setEmail("amit.kumar@example.com");
        patReq1.setAddress("42 MG Road, Sector 14, New Delhi");
        patReq1.setBloodGroup("O+");
        PatientResponseDTO pat1 = patientService.createPatient(patReq1);

        PatientRequestDTO patReq2 = new PatientRequestDTO();
        patReq2.setFullName("Priya Sundaram");
        patReq2.setAge(28);
        patReq2.setGender(Gender.FEMALE);
        patReq2.setMobile("9123456789");
        patReq2.setEmail("priya.sundaram@example.com");
        patReq2.setAddress("108 Park Street, Kolkata");
        patReq2.setBloodGroup("B+");
        PatientResponseDTO pat2 = patientService.createPatient(patReq2);

        // 5. Create Lab Order
        LabOrderRequestDTO orderReq1 = new LabOrderRequestDTO();
        orderReq1.setPatientId(pat1.getId());
        orderReq1.setDoctorId(doc1.getId());
        orderReq1.setTestIds(List.of(testCbc.getId(), testFbg.getId()));
        orderReq1.setDiscountAmount(50.0);
        orderReq1.setPaymentStatus(PaymentStatus.PAID);
        LabOrderResponseDTO order1 = orderService.createOrder(orderReq1);

        // 6. Enter Results & Generate Lab Report
        LabReportRequestDTO reportReq1 = new LabReportRequestDTO();
        reportReq1.setOrderId(order1.getId());
        reportReq1.setVerifiedBy("Dr. S. K. Gupta (MD Pathology)");
        reportReq1.setIsApproved(true);
        reportReq1.setClinicalNotes("Patient fasting blood sugar levels are slightly elevated. Hemoglobin level normal.");

        LabReportRequestDTO.ResultInputDTO res1 = new LabReportRequestDTO.ResultInputDTO();
        res1.setTestId(testCbc.getId());
        res1.setResultValue("14.5");
        res1.setNumericValue(14.5);
        res1.setRemarks("Normal");

        LabReportRequestDTO.ResultInputDTO res2 = new LabReportRequestDTO.ResultInputDTO();
        res2.setTestId(testFbg.getId());
        res2.setResultValue("118.0");
        res2.setNumericValue(118.0);
        res2.setRemarks("Slightly elevated fasting sugar");

        reportReq1.setResults(List.of(res1, res2));
        reportService.createOrUpdateReport(reportReq1);

        log.info("Demo data successfully seeded in database!");
    }
}
