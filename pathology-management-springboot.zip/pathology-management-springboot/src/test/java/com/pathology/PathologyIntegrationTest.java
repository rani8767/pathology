package com.pathology;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pathology.dto.*;
import com.pathology.model.enums.Gender;
import com.pathology.model.enums.PaymentStatus;
import com.pathology.model.enums.SampleType;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.AutoConfigureMockMvc;
import org.springframework.boot.test.context.SpringBootTest;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;
import org.springframework.test.web.servlet.MvcResult;

import java.util.List;

import static org.hamcrest.Matchers.*;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@SpringBootTest
@AutoConfigureMockMvc
class PathologyIntegrationTest {

    @Autowired
    private MockMvc mockMvc;

    @Autowired
    private ObjectMapper objectMapper;

    @Test
    @DisplayName("End-To-End Workflow: Create Category -> Create Test -> Register Patient -> Book Order -> Submit Report -> Verify Dashboard")
    void testFullPathologyWorkflow() throws Exception {
        // 1. Create Category
        CategoryDTO catReq = CategoryDTO.builder().name("Radiology & Scans").description("Imaging services").build();
        MvcResult catResult = mockMvc.perform(post("/api/v1/categories")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(catReq)))
                .andExpect(status().isCreated())
                .andReturn();
        ApiResponseDTO<?> catResponse = objectMapper.readValue(catResult.getResponse().getContentAsString(), ApiResponseDTO.class);
        Long categoryId = Long.parseLong(((java.util.Map<?, ?>) catResponse.getData()).get("id").toString());

        // 2. Create Pathology Test
        PathologyTestRequestDTO testReq = new PathologyTestRequestDTO();
        testReq.setTestName("Chest X-Ray PA View");
        testReq.setCategoryId(categoryId);
        testReq.setPrice(600.0);
        testReq.setSampleType(SampleType.OTHER);
        testReq.setNormalRangeText("Clear lungs");
        MvcResult testResult = mockMvc.perform(post("/api/v1/tests")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(testReq)))
                .andExpect(status().isCreated())
                .andReturn();
        ApiResponseDTO<?> testApiResponse = objectMapper.readValue(testResult.getResponse().getContentAsString(), ApiResponseDTO.class);
        Long testId = Long.parseLong(((java.util.Map<?, ?>) testApiResponse.getData()).get("id").toString());

        // 3. Register Patient
        PatientRequestDTO patientReq = new PatientRequestDTO();
        patientReq.setFullName("Ramesh Kumar");
        patientReq.setAge(45);
        patientReq.setGender(Gender.MALE);
        patientReq.setMobile("9811223344");
        patientReq.setEmail("ramesh@example.com");
        patientReq.setBloodGroup("A+");
        MvcResult patResult = mockMvc.perform(post("/api/v1/patients")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(patientReq)))
                .andExpect(status().isCreated())
                .andReturn();
        ApiResponseDTO<?> patApiResponse = objectMapper.readValue(patResult.getResponse().getContentAsString(), ApiResponseDTO.class);
        Long patientId = Long.parseLong(((java.util.Map<?, ?>) patApiResponse.getData()).get("id").toString());

        // 4. Book Order
        LabOrderRequestDTO orderReq = new LabOrderRequestDTO();
        orderReq.setPatientId(patientId);
        orderReq.setTestIds(List.of(testId));
        orderReq.setDiscountAmount(50.0);
        orderReq.setPaymentStatus(PaymentStatus.PAID);
        MvcResult orderResult = mockMvc.perform(post("/api/v1/orders")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(orderReq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.netAmount").value(550.0))
                .andReturn();
        ApiResponseDTO<?> orderApiResponse = objectMapper.readValue(orderResult.getResponse().getContentAsString(), ApiResponseDTO.class);
        Long orderId = Long.parseLong(((java.util.Map<?, ?>) orderApiResponse.getData()).get("id").toString());

        // 5. Submit Lab Report
        LabReportRequestDTO reportReq = new LabReportRequestDTO();
        reportReq.setOrderId(orderId);
        reportReq.setVerifiedBy("Dr. Radiologist");
        reportReq.setIsApproved(true);
        reportReq.setClinicalNotes("Normal X-Ray findings.");
        LabReportRequestDTO.ResultInputDTO rInput = new LabReportRequestDTO.ResultInputDTO();
        rInput.setTestId(testId);
        rInput.setResultValue("Clear");
        rInput.setRemarks("No infiltrates");
        reportReq.setResults(List.of(rInput));

        mockMvc.perform(post("/api/v1/reports")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(reportReq)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.data.isApproved").value(true));

        // 6. Verify Dashboard Metrics
        mockMvc.perform(get("/api/v1/dashboard/summary"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.data.totalPatients", greaterThanOrEqualTo(1)))
                .andExpect(jsonPath("$.data.totalOrders", greaterThanOrEqualTo(1)));
    }
}
