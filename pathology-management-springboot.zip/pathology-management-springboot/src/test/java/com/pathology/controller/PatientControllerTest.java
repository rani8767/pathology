package com.pathology.controller;

import com.fasterxml.jackson.databind.ObjectMapper;
import com.pathology.dto.PatientRequestDTO;
import com.pathology.dto.PatientResponseDTO;
import com.pathology.model.enums.Gender;
import com.pathology.service.PatientService;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.boot.test.autoconfigure.web.servlet.WebMvcTest;
import org.springframework.boot.test.mock.mockito.MockBean;
import org.springframework.http.MediaType;
import org.springframework.test.web.servlet.MockMvc;

import java.util.List;

import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;
import static org.springframework.test.web.servlet.request.MockMvcRequestBuilders.*;
import static org.springframework.test.web.servlet.result.MockMvcResultMatchers.*;

@WebMvcTest(PatientController.class)
class PatientControllerTest {

    @Autowired
    private MockMvc mockMvc;

    @MockBean
    private PatientService patientService;

    @Autowired
    private ObjectMapper objectMapper;

    private PatientResponseDTO mockPatient;

    @BeforeEach
    void setUp() {
        mockPatient = PatientResponseDTO.builder()
                .id(1L)
                .patientCode("PAT-12345678")
                .fullName("John Doe")
                .age(30)
                .gender(Gender.MALE)
                .mobile("9876543210")
                .email("john.doe@example.com")
                .address("123 Street")
                .bloodGroup("A+")
                .build();
    }

    @Test
    @DisplayName("POST /api/v1/patients - Should register patient successfully")
    void testCreatePatient() throws Exception {
        PatientRequestDTO request = new PatientRequestDTO();
        request.setFullName("John Doe");
        request.setAge(30);
        request.setGender(Gender.MALE);
        request.setMobile("9876543210");
        request.setEmail("john.doe@example.com");
        request.setAddress("123 Street");
        request.setBloodGroup("A+");

        when(patientService.createPatient(any(PatientRequestDTO.class))).thenReturn(mockPatient);

        mockMvc.perform(post("/api/v1/patients")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isCreated())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data.fullName").value("John Doe"))
                .andExpect(jsonPath("$.data.patientCode").value("PAT-12345678"));
    }

    @Test
    @DisplayName("GET /api/v1/patients - Should return all patients")
    void testGetAllPatients() throws Exception {
        when(patientService.getAllPatients()).thenReturn(List.of(mockPatient));

        mockMvc.perform(get("/api/v1/patients"))
                .andExpect(status().isOk())
                .andExpect(jsonPath("$.success").value(true))
                .andExpect(jsonPath("$.data[0].fullName").value("John Doe"));
    }

    @Test
    @DisplayName("POST /api/v1/patients - Invalid Input Should Return 400 Bad Request")
    void testCreatePatientInvalidInput() throws Exception {
        PatientRequestDTO request = new PatientRequestDTO();
        request.setFullName(""); // invalid blank
        request.setAge(-5);     // invalid age

        mockMvc.perform(post("/api/v1/patients")
                        .contentType(MediaType.APPLICATION_JSON)
                        .content(objectMapper.writeValueAsString(request)))
                .andExpect(status().isBadRequest())
                .andExpect(jsonPath("$.success").value(false));
    }
}
