package com.pathology.service;

import com.pathology.dto.LabReportRequestDTO;
import com.pathology.dto.LabReportResponseDTO;
import com.pathology.model.*;
import com.pathology.model.enums.Gender;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.ResultStatus;
import com.pathology.model.enums.SampleType;
import com.pathology.repository.LabOrderRepository;
import com.pathology.repository.LabReportRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.when;

@ExtendWith(MockitoExtension.class)
class LabReportServiceTest {

    @Mock
    private LabReportRepository reportRepository;

    @Mock
    private LabOrderRepository orderRepository;

    @InjectMocks
    private LabReportService reportService;

    private LabOrder mockOrder;
    private PathologyTest mockTest;

    @BeforeEach
    void setUp() {
        Patient patient = Patient.builder().id(1L).fullName("Test Patient").age(30).gender(Gender.MALE).mobile("9999999999").build();
        mockTest = PathologyTest.builder()
                .id(5L)
                .testName("Fasting Sugar")
                .refMinValue(70.0)
                .refMaxValue(100.0)
                .unit("mg/dL")
                .sampleType(SampleType.BLOOD)
                .price(200.0)
                .build();

        OrderItem item = OrderItem.builder().id(1L).test(mockTest).price(200.0).build();
        mockOrder = LabOrder.builder()
                .id(20L)
                .orderNumber("ORD-TEST-1")
                .patient(patient)
                .items(List.of(item))
                .orderStatus(OrderStatus.PENDING)
                .totalAmount(200.0)
                .netAmount(200.0)
                .build();
    }

    @Test
    @DisplayName("Create Lab Report - Auto evaluates Abnormal result correctly")
    void testCreateReportAbnormalResult() {
        LabReportRequestDTO request = new LabReportRequestDTO();
        request.setOrderId(20L);
        request.setVerifiedBy("Dr. Pathologist");

        LabReportRequestDTO.ResultInputDTO resultInput = new LabReportRequestDTO.ResultInputDTO();
        resultInput.setTestId(5L);
        resultInput.setResultValue("130.0");
        resultInput.setNumericValue(130.0);
        request.setResults(List.of(resultInput));

        when(orderRepository.findById(20L)).thenReturn(Optional.of(mockOrder));
        when(reportRepository.findByOrderId(20L)).thenReturn(Optional.empty());
        when(reportRepository.save(any(LabReport.class))).thenAnswer(invocation -> {
            LabReport rpt = invocation.getArgument(0);
            rpt.setId(100L);
            return rpt;
        });

        LabReportResponseDTO response = reportService.createOrUpdateReport(request);

        assertNotNull(response);
        assertEquals(100L, response.getId());
        assertEquals(1, response.getResults().size());
        assertEquals(ResultStatus.ABNORMAL, response.getResults().get(0).getResultStatus());
        assertEquals(OrderStatus.COMPLETED, mockOrder.getOrderStatus());
    }
}
