package com.pathology.service;

import com.pathology.dto.LabOrderRequestDTO;
import com.pathology.dto.LabOrderResponseDTO;
import com.pathology.exception.BadRequestException;
import com.pathology.exception.ResourceNotFoundException;
import com.pathology.model.LabOrder;
import com.pathology.model.Patient;
import com.pathology.model.PathologyTest;
import com.pathology.model.enums.Gender;
import com.pathology.model.enums.OrderStatus;
import com.pathology.model.enums.PaymentStatus;
import com.pathology.model.enums.SampleType;
import com.pathology.repository.DoctorRepository;
import com.pathology.repository.LabOrderRepository;
import com.pathology.repository.PatientRepository;
import com.pathology.repository.PathologyTestRepository;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.DisplayName;
import org.junit.jupiter.api.Test;
import org.junit.jupiter.api.extension.ExtendWith;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.junit.jupiter.MockitoExtension;

import java.util.List;
import java.util.Optional;

import static org.junit.jupiter.api.Assertions.*;
import static org.mockito.ArgumentMatchers.any;
import static org.mockito.Mockito.*;

@ExtendWith(MockitoExtension.class)
class LabOrderServiceTest {

    @Mock
    private LabOrderRepository orderRepository;

    @Mock
    private PatientRepository patientRepository;

    @Mock
    private DoctorRepository doctorRepository;

    @Mock
    private PathologyTestRepository testRepository;

    @InjectMocks
    private LabOrderService orderService;

    private Patient mockPatient;
    private PathologyTest mockTest;

    @BeforeEach
    void setUp() {
        mockPatient = Patient.builder()
                .id(1L)
                .patientCode("PAT-100")
                .fullName("Alice Smith")
                .age(29)
                .gender(Gender.FEMALE)
                .mobile("9876543210")
                .build();

        mockTest = PathologyTest.builder()
                .id(10L)
                .testCode("TST-01")
                .testName("CBC")
                .price(500.0)
                .sampleType(SampleType.BLOOD)
                .build();
    }

    @Test
    @DisplayName("Create Order - Success scenario")
    void testCreateOrderSuccess() {
        LabOrderRequestDTO request = new LabOrderRequestDTO();
        request.setPatientId(1L);
        request.setTestIds(List.of(10L));
        request.setDiscountAmount(50.0);
        request.setPaymentStatus(PaymentStatus.PAID);

        when(patientRepository.findById(1L)).thenReturn(Optional.of(mockPatient));
        when(testRepository.findAllById(List.of(10L))).thenReturn(List.of(mockTest));
        when(orderRepository.save(any(LabOrder.class))).thenAnswer(invocation -> {
            LabOrder order = invocation.getArgument(0);
            order.setId(100L);
            return order;
        });

        LabOrderResponseDTO result = orderService.createOrder(request);

        assertNotNull(result);
        assertEquals(100L, result.getId());
        assertEquals(500.0, result.getTotalAmount());
        assertEquals(50.0, result.getDiscountAmount());
        assertEquals(450.0, result.getNetAmount());
        assertEquals(OrderStatus.PENDING, result.getOrderStatus());
    }

    @Test
    @DisplayName("Create Order - Non-existent patient should throw ResourceNotFoundException")
    void testCreateOrderPatientNotFound() {
        LabOrderRequestDTO request = new LabOrderRequestDTO();
        request.setPatientId(99L);
        request.setTestIds(List.of(10L));

        when(patientRepository.findById(99L)).thenReturn(Optional.empty());

        assertThrows(ResourceNotFoundException.class, () -> orderService.createOrder(request));
    }

    @Test
    @DisplayName("Create Order - Discount greater than total amount should throw BadRequestException")
    void testCreateOrderExcessiveDiscount() {
        LabOrderRequestDTO request = new LabOrderRequestDTO();
        request.setPatientId(1L);
        request.setTestIds(List.of(10L));
        request.setDiscountAmount(600.0); // Total price is 500.0

        when(patientRepository.findById(1L)).thenReturn(Optional.of(mockPatient));
        when(testRepository.findAllById(List.of(10L))).thenReturn(List.of(mockTest));

        assertThrows(BadRequestException.class, () -> orderService.createOrder(request));
    }
}
